// Donasiaja
(function ($) {
    console.log('You are in DonasiAja Dashboard.');
})(jQuery)
